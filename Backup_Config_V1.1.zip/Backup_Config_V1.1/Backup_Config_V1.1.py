#from cmath import log
from netmiko import ConnectHandler
import getpass
#import sys
import time
import os

##getting system date 
day=time.strftime('%d')
month=time.strftime('%m')
year=time.strftime('%Y')
today=day+"-"+month+"-"+year

##initialising device
device = {
    'device_type': 'cisco_ios',
    }
##opening IP file
ipfile=open("List IP Address.txt")
print ("Script to take backup of devices, Please enter your credential\n")
device['username']=input("username : ")
device['password']=getpass.getpass()

##taking backup
for switch in ipfile:
 try:
     device['host']=switch.strip("\n")
     print("\n\nConnecting Device ",switch)
     net_connect = ConnectHandler(**device)
     net_connect.enable()
     time.sleep(1)
     print ("Reading the running config ")
     hostname = net_connect.send_command('show run | i hostname')
     hostname.split(" ")
     col1,col2 = hostname.split(" ")
     output1 = net_connect.send_command('show ver')
     output2 = net_connect.send_command('show ip int bri | inc 10.236.30.')
     output3 = net_connect.send_command('show cdp nei')
     output4 = net_connect.send_command('show cdp nei det')
     output5 = net_connect.send_command('show inv')
     time.sleep(3)
     path='Backup'
     filename=col2+'-'+today+".txt"
     folderbackup = os.path.join(path, filename)
     saveconfig=open(folderbackup,'w+')
     print("Writing Configuration to file")
     saveconfig.write(col2 + "# show version\n")
     saveconfig.write(output1)
     saveconfig.write("\n")
     saveconfig.write(col2 + "# show ip interface brief | inc 10.236.30.\n")
     saveconfig.write(output2)
     saveconfig.write("\n")
     saveconfig.write(col2 + "# show cdp neighbors\n")
     saveconfig.write(output3)
     saveconfig.write("\n")
     saveconfig.write(col2 + "# show cdp neighbors detail\n")
     saveconfig.write(output4)
     saveconfig.write("\n")
     saveconfig.write(col2 + "# show inventory\n")
     saveconfig.write(output5)
     saveconfig.write("\n")
     saveconfig.close()
     time.sleep(2)
     net_connect.disconnect()
     print ("Configuration saved to file",filename)
 except:
     path3='log'
     logbackup="Log backup failed.txt"
     folderlog = os.path.join(path3, logbackup)
     backupfailed=open(folderlog,'a+')
     print ("Access to "+device['host']+" failed, backup did not taken")
     backupfailed.write("Access to "+device['host']+" failed, backup did not taken\n")

ipfile.close()
print ("\nAll device backup completed")
